# bai tap tuan 12 nhap mon lap trinh

## ref

**Author**: Thuan Pham

**See newest update at:**

[https://github.com/thuanpham2311/lazyscript/tree/master/nhapMonLapTrinh/phamTanThuanDH51902283_nhapMonLapTrinh_week12](https://github.com/thuanpham2311/lazyscript/tree/master/nhapMonLapTrinh/phamTanThuanDH51902283_nhapMonLapTrinh_week12)

###### Date Created: Sat 04 Jul 2020 11:38:08 PM +07
